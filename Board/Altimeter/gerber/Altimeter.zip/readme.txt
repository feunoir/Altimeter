I need some holes not plated.
Please check "Altimeter-NPTH.TXT".